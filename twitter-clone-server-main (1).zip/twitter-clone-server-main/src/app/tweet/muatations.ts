export const muatations = `#graphql
    createTweet(payload: CreateTweetData!): Tweet
`;
