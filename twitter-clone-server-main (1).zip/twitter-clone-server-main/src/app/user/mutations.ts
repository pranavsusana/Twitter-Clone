export const mutations = `#graphql
    followUser(to: ID!): Boolean
    unfollowUser(to: ID!): Boolean
`;
